package com.gaspar.todolist.ui

import android.annotation.SuppressLint
import android.app.*
import android.content.ClipDescription
import android.content.Intent
import android.graphics.Color
import android.os.*
import android.view.View
import android.widget.DatePicker
import android.widget.TimePicker
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isEmpty
import com.gaspar.todolist.R
import com.gaspar.todolist.alarm.AlarmReceiver
import com.gaspar.todolist.databinding.ActivityAddTaskBinding
import com.gaspar.todolist.datasource.Constant
import com.gaspar.todolist.datasource.OwlDB
import com.gaspar.todolist.datasource.TaskDataSource
import com.gaspar.todolist.extensions.format
import com.gaspar.todolist.extensions.text
import com.gaspar.todolist.model.Owl
import com.gaspar.todolist.model.Task
import com.google.android.material.datepicker.MaterialDatePicker
import com.google.android.material.timepicker.MaterialTimePicker
import com.google.android.material.timepicker.TimeFormat
import kotlinx.android.synthetic.main.activity_add_task.*
import kotlinx.android.synthetic.main.activity_task.*
import kotlinx.android.synthetic.main.item.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.intellij.lang.annotations.JdkConstants
import java.util.*
import kotlin.concurrent.timer
import kotlin.concurrent.timerTask

class AddTaskActivity : AppCompatActivity() {
    private var mYear: Int = 0
    private var mMonth:Int = 0
    private var mDay: Int = 0
    private var mHour: Int = 0
    private var mMinute:Int = 0
    private lateinit var binding: ActivityAddTaskBinding
    private lateinit var runnable: Runnable
    private val c = Calendar.getInstance()
    private val timePicker = MaterialTimePicker.Builder()
        .setTimeFormat(TimeFormat.CLOCK_24H)
        .build()
    val datePicker = MaterialDatePicker.Builder.datePicker().build()
    private val db by lazy { OwlDB(this) }
    private var owlId: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityAddTaskBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setupView()
        insertListeners()
    }

    private fun setupView(){
        when(intent.getIntExtra("intent_type", 0)){
            Constant.TYPE_CREATE ->{
                binding.btnUpdate.visibility = View.GONE
            }
            Constant.TYPE_READ ->{
                binding.btnNewTask.visibility = View.GONE
                binding.btnUpdate.visibility = View.GONE
                getOwlTask()
            }
            Constant.TYPE_UPDATE ->{
                binding.btnNewTask.visibility = View.GONE
                getOwlTask()
            }
        }
    }

    @SuppressLint("SetTextI18n")
    private fun insertListeners() {
        /*binding.tilDate.editText?.setOnClickListener {
            mYear = c[Calendar.YEAR]
            mMonth = c[Calendar.MONTH]
            mDay = c[Calendar.DAY_OF_MONTH]
            val datePickerDialog = DatePickerDialog(
                this,
                {_:DatePicker?, year:Int, monthOfYear:Int, dayOfMonth: Int ->
                binding.tilDate.text = dayOfMonth.toString() + "-" + (monthOfYear + 1) + "-" + year
            }, mYear, mMonth,mDay)
            datePickerDialog.show()*/


        binding.tilDate.editText?.setOnClickListener{
            datePicker.addOnPositiveButtonClickListener {
                val timeZone = TimeZone.getDefault()
                val offset = timeZone.getOffset(Date().time) * -1
                binding.tilDate.text = Date(it + offset).format()
            }
            datePicker.show(supportFragmentManager, "DATE_PICKER_TAG")
        }


       /* binding.tilHour.editText?.setOnClickListener {
            mHour = c[Calendar.HOUR_OF_DAY]
            mMinute = c[Calendar.MINUTE]
            val timePickerDialog = TimePickerDialog(
                this,
                { _: TimePicker?, hourOfDay:Int, minute:Int->
                    binding.tilHour.text = "$hourOfDay:$minute"
                }, mHour, mMinute, false)
            timePickerDialog.show()*/

        binding.tilHour.editText?.setOnClickListener {
            timePicker.addOnPositiveButtonClickListener {
                val minute = if (timePicker.minute in 0..9) "0${timePicker.minute}" else timePicker.minute
                val hour = if (timePicker.hour in 0..9) "0${timePicker.hour}" else timePicker.hour

                binding.tilHour.text = "$hour:$minute"
            }

            timePicker.show(supportFragmentManager, null)
        }


        binding.btnUpdate.setOnClickListener {
            if(til_title.text.toString().isEmpty() || til_description.text.toString().isEmpty()  || til_date.text.toString().isEmpty()  || til_hour.text.toString().isEmpty() ){
                showWarningToast()
                shakeItBaby()
            }else{
                btn_update.setText("Atualizando...")
                CoroutineScope(Dispatchers.IO).launch {
                    db.owlDao().updateTask(
                        Owl(owlId, til_title.text.toString(), til_description.text.toString(), til_date.text.toString(), til_hour.text.toString())
                    )
                }
                Handler().postDelayed({
                    showSuccessToast()
                    shakeItBaby()
                    finish()
                }, 2500)
            }
        }

        binding.btnNewTask.setOnClickListener {
            if(til_title.text.toString().isEmpty() || til_description.text.toString().isEmpty()  || til_date.text.toString().isEmpty()  || til_hour.text.toString().isEmpty() ){
                showWarningToast()
                shakeItBaby()
            }else{
                btn_new_task.setText("Aguarde...")
                CoroutineScope(Dispatchers.IO).launch {
                    db.owlDao().addTask(
                        owl = Owl(0, til_title.text.toString(), til_description.text.toString(), til_date.text.toString(), til_hour.text.toString())
                    )
                }
                Handler().postDelayed({
                    showSuccessToast()
                    shakeItBaby()
                    finish()
                }, 2500)
                //setReminder(til_title.text, til_description.text)
            }
        }
    }

    private fun getOwlTask() {
        owlId = intent.getIntExtra("intent_id", 0)
        CoroutineScope(Dispatchers.IO).launch {
            val tasks = db.owlDao().getTask(owlId)[0]
            Thread(Runnable {
                this@AddTaskActivity.runOnUiThread {
                    binding.editTitle.setText(tasks.title)
                    binding.editDescription.setText(tasks.description_task)
                    binding.editDate.setText(tasks.date)
                    binding.editHora.setText(tasks.hour)
                }
                Thread.sleep(1000)
            }).start()
        }
    }

    private fun showSuccessToast(){
        val toast = Toast(this)
        toast.duration = Toast.LENGTH_LONG
        val customView: View = layoutInflater.inflate(R.layout.custom_toast_sucess, null)
        toast.setView(customView)
        toast.show()
    }

    private fun showWarningToast(){
        val toast = Toast(this)
        toast.duration = Toast.LENGTH_LONG
        val customView: View = layoutInflater.inflate(R.layout.custom_toast_aviso, null)
        toast.setView(customView)
        toast.show()
    }

    private fun  shakeItBaby(){
        if(Build.VERSION.SDK_INT >= 26){
            (applicationContext.getSystemService(VIBRATOR_SERVICE) as Vibrator).vibrate(
                VibrationEffect.createOneShot(150, VibrationEffect.DEFAULT_AMPLITUDE))
        }else{
            (applicationContext.getSystemService(VIBRATOR_SERVICE) as Vibrator).vibrate(150)
        }

    }

    /*private fun setReminder(title: String, description: String) {
        val alarmManager = getSystemService(ALARM_SERVICE) as AlarmManager
        val intent = Intent(this, AlarmReceiver::class.java)
        intent.putExtra("title", title )
        intent.putExtra("description", description)
        val pendingIntent = PendingIntent.getBroadcast(this, 0, intent, 0)
        alarmManager.setExact(AlarmManager.RTC_WAKEUP, c.timeInMillis, pendingIntent)
        //Toast.makeText(this, "Alarm is set", Toast.LENGTH_SHORT).show()
    }*/
}