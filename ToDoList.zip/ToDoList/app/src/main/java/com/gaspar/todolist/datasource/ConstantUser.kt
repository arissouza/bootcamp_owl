package com.gaspar.todolist.datasource

class ConstantUser {
    companion object{
        const val TYPE_READ_USER = 0;
        const val TYPE_CREATE_USER = 1;
        const val TYPE_UPDATE_USER = 2;
    }
}