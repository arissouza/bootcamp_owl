package com.gaspar.todolist.ui

import android.annotation.SuppressLint
import android.text.Layout
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.gaspar.todolist.R
import com.gaspar.todolist.model.Owl
import kotlinx.android.synthetic.main.item.view.*
import java.util.*
import kotlin.collections.ArrayList

class OwlListAdapter (private val tasks: ArrayList<Owl>, private val listener: OnAdapterListener):
    RecyclerView.Adapter<OwlListAdapter.OwlViewHolder>(){
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int
    ): OwlListAdapter.OwlViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item, parent, false)
        return OwlViewHolder(view)
    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: OwlListAdapter.OwlViewHolder, position: Int){
        val owl = tasks[position]
        holder.view.tv_title.text = owl.title
        holder.view.desc.text = owl.description_task
        holder.view.tv_date.text = "${owl.date} ${owl.hour}"
        holder.view.visualizar.setOnClickListener {
            listener.expandClick(owl)
        }
        holder.view.editar.setOnClickListener {
            listener.onUpdate(owl)
        }
        holder.view.excluir.setOnClickListener {
            listener.onDelete(owl)
        }
        holder.view.cardOwlTask.setOnClickListener{
            listener.onClick(owl)
        }
    }

    override fun getItemCount(): Int {
        return tasks.size
    }

    class OwlViewHolder(val view: View): RecyclerView.ViewHolder(view)

    fun setData(list: List<Owl>){
        tasks.clear()
        tasks.addAll(list)
        notifyDataSetChanged()
    }

    interface OnAdapterListener{
        fun expandClick(owl: Owl)
        fun onClick(owl: Owl)
        fun onUpdate(owl: Owl)
        fun onDelete(owl: Owl)
    }

}