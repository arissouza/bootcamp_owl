package com.gaspar.todolist.ui

import android.app.*
import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Bundle
import android.provider.CalendarContract
import android.provider.CalendarContract.CONTENT_URI
import android.provider.CalendarContract.Events.*
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import com.gaspar.todolist.alarm.AlarmReceiver
import com.gaspar.todolist.databinding.ActivityTaskBinding
import com.gaspar.todolist.datasource.*
import com.gaspar.todolist.model.Owl
import com.gaspar.todolist.viewmodel.DataStoreViewModel
import com.gaspar.todolist.viewmodel.UserViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.android.synthetic.main.activity_task.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.*

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    private val db by lazy { OwlDB(this) }
    lateinit var owlListAdapter: OwlListAdapter;
    private lateinit var binding: ActivityTaskBinding
    private lateinit var runnable: Runnable

    private val userViewModel: UserViewModel by viewModels()
    private val dataStoreViewModel: DataStoreViewModel by viewModels()

    //private val adapter by lazy { TaskListAdapter() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTaskBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupListeners()
        setupRV()

    }

    override fun onStart() {
        super.onStart()
        loadOwlTasks()
        loadUserInfo()
    }


    private fun loadOwlTasks() {
        CoroutineScope(Dispatchers.IO).launch {
            val tasks = db.owlDao().getTasks()
            Log.d("MainActivity", "dbResource: $tasks")
            withContext(Dispatchers.Main) {
                owlListAdapter.setData(tasks)
                owlListAdapter.notifyDataSetChanged()
            }
            if (tasks.isEmpty()) {
                Thread(Runnable {
                    this@MainActivity.runOnUiThread {
                        include_empty.visibility = View.VISIBLE
                    }
                    Thread.sleep(1000)
                }).start()
            } else {
                Thread(Runnable {
                    this@MainActivity.runOnUiThread {
                        include_empty.visibility = View.GONE
                    }
                    Thread.sleep(1000)
                }).start()
            }
        }
    }

    private fun loadUserInfo(){
        this.lifecycleScope.launch {
            lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED){

                userViewModel.doGetUserDetails()
                userViewModel.userDetails.collect{ users->

                    for (user in users){
                        //set data into view
                        binding.userName.text = user.apelido
                    }

                }
            }
        }
    }


    private fun setupListeners() {
        binding.fabAddTask.setOnClickListener {
            intentTasks(0, Constant.TYPE_CREATE)
        }
    }


    fun intentTasks(owlId: Int, intentType: Int){
        startActivity(Intent(applicationContext, AddTaskActivity::class.java)
            .putExtra("intent_id", owlId)
            .putExtra("intent_type", intentType)
        )
    }

    private fun setupRV(){
        owlListAdapter = OwlListAdapter(arrayListOf(), object : OwlListAdapter.OnAdapterListener{
            override fun onClick(owl: Owl) {
                Thread(Runnable {
                    this@MainActivity.runOnUiThread {
                        startAgenda(owl)
                    }
                    Thread.sleep(1000)
                }).start()
            }

            override fun onDelete(owl: Owl) {
                Thread(Runnable {
                    this@MainActivity.runOnUiThread {
                        deleteDialog(owl)
                    }
                    Thread.sleep(1000)
                    loadOwlTasks()
                }).start()
            }

            override fun expandClick(owl: Owl) {
                Thread(Runnable {
                    this@MainActivity.runOnUiThread {
                        showInfoDialog(owl)
                    }
                    Thread.sleep(1000)
                }).start()
            }

            override fun onUpdate(owl: Owl) {
                intentTasks(owl.id, Constant.TYPE_UPDATE)
            }
        })
        lista_tarefas.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = owlListAdapter
            owlListAdapter.notifyDataSetChanged()
        }
    }

    private fun deleteDialog(owl: Owl){
        val alertDialog = AlertDialog.Builder(this)
        alertDialog.apply {
            setTitle("Confirmação")
            setMessage("Deseja excluir o item ${owl.title}?")
            setNegativeButton("Não"){
                dialog, _->
                dialog.dismiss()
            }
            setPositiveButton("Sim"){dialog, _->
                dialog.dismiss()
                CoroutineScope(Dispatchers.IO).launch {
                    db.owlDao().deleteTask(owl)
                }
            }
        }
        alertDialog.show()
    }

    private fun showInfoDialog(owl: Owl){
        val alertDialog = AlertDialog.Builder(this)
        alertDialog.apply {
            setTitle(owl.title)
            setMessage(owl.description_task)
            setPositiveButton("Ok"){
                    dialog, _->
                dialog.dismiss()
            }
        }
        alertDialog.show()
    }

    private fun startAgenda(owl: Owl){
        val intent = Intent(Intent.ACTION_EDIT).setData(CalendarContract.Events.CONTENT_URI)
            .putExtra(TITLE, owl.title)
            .putExtra(DESCRIPTION, owl.description_task)
            .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, owl.hour)
            .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, System.currentTimeMillis() + (60*60*100))
            .putExtra(CalendarContract.Events.AVAILABILITY, CalendarContract.Events.AVAILABILITY_BUSY)
        try {
            startActivity(intent)
        }catch (exception: ActivityNotFoundException){
            Toast.makeText(applicationContext, "Instale o Aplicativo Google Agenda", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setReminder(calendar: Calendar) {
        val alarmManager = getSystemService(ALARM_SERVICE) as AlarmManager
        val intent = Intent(this, AlarmReceiver::class.java)
        intent.putExtra("title", "This is Alarm Title")
        intent.putExtra("description", "This is Alarm Description")
        val pendingIntent = PendingIntent.getBroadcast(this, 0, intent, 0)
        alarmManager.setExact(AlarmManager.RTC_WAKEUP, calendar.timeInMillis, pendingIntent)
        Toast.makeText(this, "Alarm is set", Toast.LENGTH_SHORT).show()
    }
}