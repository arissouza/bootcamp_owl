package com.gaspar.todolist.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
class Owl (
    @PrimaryKey(autoGenerate = true)
    val id: Int,
    val title: String,
    val description_task: String,
    val date: String,
    val hour: String
)