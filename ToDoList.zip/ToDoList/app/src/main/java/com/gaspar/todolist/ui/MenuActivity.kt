package com.gaspar.todolist.ui

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.gaspar.todolist.R
import com.gaspar.todolist.SobreActivity
import com.gaspar.todolist.databinding.ActivityPerfilBinding
import com.gaspar.todolist.databinding.MenuActivityBinding
import com.gaspar.todolist.datasource.Constant
import com.gaspar.todolist.model.User
import com.gaspar.todolist.viewmodel.DataStoreViewModel
import com.gaspar.todolist.viewmodel.UserViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.android.synthetic.main.activity_add_task.*
import kotlinx.android.synthetic.main.activity_perfil.*
import kotlinx.android.synthetic.main.activity_task.*
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import java.util.*

@AndroidEntryPoint
class MenuActivity : AppCompatActivity() {
    private lateinit var binding: MenuActivityBinding
    private val dataStoreViewModel: DataStoreViewModel by viewModels()
    private val userViewModel: UserViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = MenuActivityBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        initViews()


    }
    private fun initViews(){
        loadUserInfo()
        setupListeners()
    }

    private fun setupListeners() {

        binding.editarApelido.setOnClickListener {
            val intent = Intent(this, EditarPerfil::class.java)
            startActivity(intent)
        }

        binding.tarefas.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }


        binding.sobre.setOnClickListener {
            val intent = Intent(this, SobreActivity::class.java)
            startActivity(intent)
        }

    }

    private fun loadUserInfo(){
        this.lifecycleScope.launch {
            lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED){

                userViewModel.doGetUserDetails()
                userViewModel.userDetails.collect{ users->

                    for (user in users){
                        //set data into view
                        binding.userName.text = user.apelido
                    }

                }
            }
        }
    }

}