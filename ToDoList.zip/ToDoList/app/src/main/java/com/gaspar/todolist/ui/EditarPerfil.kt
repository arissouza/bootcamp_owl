package com.gaspar.todolist.ui

import android.content.Context
import android.content.Intent
import android.os.*
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.gaspar.todolist.R
import com.gaspar.todolist.databinding.ActivityEditarPerfilBinding
import com.gaspar.todolist.databinding.ActivityPerfilBinding
import com.gaspar.todolist.model.User
import com.gaspar.todolist.viewmodel.DataStoreViewModel
import com.gaspar.todolist.viewmodel.UserViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.android.synthetic.main.activity_add_task.*
import kotlinx.android.synthetic.main.activity_perfil.*
import kotlinx.android.synthetic.main.activity_task.*
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import java.util.*

@AndroidEntryPoint
class EditarPerfil : AppCompatActivity() {
    private lateinit var binding: ActivityEditarPerfilBinding
    private val dataStoreViewModel: DataStoreViewModel by viewModels()
    private val userViewModel: UserViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityEditarPerfilBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        makeButtonNotClickableAtFirst()
        initViews()


    }

    private fun loadUserInfo(){
        this.lifecycleScope.launch {
            lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED){

                userViewModel.doGetUserDetails()
                userViewModel.userDetails.collect{ users->

                    for (user in users){
                        //set data into view
                        binding.editApelido.setText(user.apelido)
                    }

                }
            }
        }
    }

    private fun initViews(){
        handleClick()
        loadUserInfo()
    }

    /**
     * Make button unclickable to avoid empty entries into room
     */

    private fun makeButtonNotClickableAtFirst(){

        //Make button UnClickable for the first time
        binding.salvarApelido.isEnabled = false
        binding.salvarApelido.background = ContextCompat.getDrawable(
            this,
            R.drawable.btn_opaque
        )

        //make the button clickable after detecting changes in input field
        val watcher: TextWatcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {

                val nameEt = binding.editApelido.text.toString()

                if (nameEt.isEmpty()) {
                    binding.salvarApelido.isEnabled = false
                    binding.salvarApelido.background = ContextCompat.getDrawable(
                        this@EditarPerfil,
                        R.drawable.btn_opaque
                    )
                } else {
                    binding.salvarApelido.isEnabled = true
                    binding.salvarApelido.background = ContextCompat.getDrawable(
                        this@EditarPerfil,
                        R.drawable.btn_round
                    )
                }
            }

            override fun afterTextChanged(s: Editable) {

            }

        }

        binding.editApelido.addTextChangedListener(watcher)

    }

    /**
     * Handle click of save button
     */
    private fun handleClick(){

        //on click of button save
        binding.salvarApelido.setOnClickListener {

            //get details entered
            val apelido = binding.editApelido.text.toString()

            val user = User(id = 1, apelido = apelido)

            //save the details to room database
            userViewModel.updateUserDetails(user)

            val intent = Intent(this, MenuActivity::class.java)
            startActivity(intent)
            finish()
            Handler().postDelayed({
                shakeItBaby()
                showSuccessToast()
            }, 500)

        }

    }

    private fun showSuccessToast(){
        val toast = Toast(this)
        toast.duration = Toast.LENGTH_LONG
        val customView: View = layoutInflater.inflate(R.layout.custom_toast_perfil, null)
        toast.setView(customView)
        toast.show()
    }

    private fun  shakeItBaby(){
        if(Build.VERSION.SDK_INT >= 26){
            (applicationContext.getSystemService(VIBRATOR_SERVICE) as Vibrator).vibrate(VibrationEffect.createOneShot(150, VibrationEffect.DEFAULT_AMPLITUDE))
        }else{
            (applicationContext.getSystemService(VIBRATOR_SERVICE) as Vibrator).vibrate(150)
        }

    }


}