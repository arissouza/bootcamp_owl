package com.gaspar.todolist.datasource

import androidx.room.*
import com.gaspar.todolist.model.Owl

@Dao
interface OwlDao {
    @Insert
    suspend fun addTask(owl: Owl)
    @Update
    suspend fun updateTask(owl: Owl)
    @Delete
    suspend fun deleteTask(owl: Owl)
    @Query("SELECT * FROM owl")
    suspend fun getTasks(): List<Owl>
    @Query("SELECT * FROM owl WHERE id=:owl_id")
    suspend fun getTask(owl_id: Int): List<Owl>
}